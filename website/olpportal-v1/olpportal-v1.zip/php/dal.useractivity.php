<?php
session_start();
require 'database.php';
/* 
 * UserActivity Class includes usercourses table, usercoursetest table, courseuserview table
 */

class UserActivity
{
    
}