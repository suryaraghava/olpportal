<?php


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* DATABASE CREDIENTIALS */
define("SERVER_NAME","localhost:3306", true);//define()is to declare constats .
define("DB_NAME","olpportal_v1", true);
define("DB_USER","root", true);
define("DB_PASSWORD","@anupanup123", true);

/*
define("SERVER_NAME","inglobal.in", true);//define()is to declare constats .
define("DB_NAME","inglobal_olpportal", true);
define("DB_USER","inglobal_surya", true);
define("DB_PASSWORD","inglobal", true);


define("SERVER_NAME","202.150.213.34", true);//define()is to declare constats .
define("DB_NAME","u371059435_olp", true);
define("DB_USER","u371059435_olp", true);
define("DB_PASSWORD","@anupanup123", true);
*/

/* SMS-LANE */
define("SMSPHONE_USERNAME","anupchinney", true);
define("SMSPHONE_PASSWORD","@anupanup123", true);
define("SMSPHONE_REGNUMBER","919160869337", true);
define("SMSPHONE_FL","0", true);    
define("SMSPHONE_SENDURL","http://www.smslane.com//vendorsms/pushsms.aspx", true);


/* SIGN-UP REGISTRATION */
define("SESSION_SIGNUP_STATE","SESSION_SIGNUP_STATE", true);
define("SESSION_SIGNUP_PHONENUMBER","SESSION_SIGNUP_PHONENUMBER", true);
define("SESSION_SIGNUP_REGID","SESSION_SIGNUP_REGID", true);
/* USER-SESSIONS */
define("SESSION_USER_REGID","SESSION_USER_REGID", true);
define("SESSION_USER_LOGID","SESSION_USER_LOGID", true);
define("SESSION_USER_USERNAME","SESSION_USER_USERNAME", true);
define("SESSION_USER_PASSWORD","SESSION_USER_PASSWORD", true);
define("SESSION_USER_FIRSTNAME","SESSION_USER_FIRSTNAME", true);
define("SESSION_USER_LASTNAME","SESSION_USER_LASTNAME", true);
define("SESSION_USER_STAFFID","SESSION_USER_STAFFID", true);
define("SESSION_USER_MOBILE","SESSION_USER_MOBILE", true);
define("SESSION_USER_EMAIL","SESSION_USER_EMAIL", true);
define("SESSION_USER_DESIGNATION","SESSION_USER_DESIGNATION", true);
define("SESSION_USER_ACTIVE","SESSION_USER_ACTIVE", true);


/* */
define("SESSION_COURSENAME","SESSION_COURSENAME", true);
define("SESSION_COURSEID","SESSION_COURSEID", true);