/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
            function popupOpen()
            {
                document.getElementById("PopupAudioFrontEnd").style.display='block';
                document.getElementById("PopupAudioBackground").style.display='block';
            }
            
            function popupClose()
            {
                document.getElementById("PopupAudioFrontEnd").style.display='none';
                document.getElementById("PopupAudioBackground").style.display='none';
            }

